package com.example.acessoscartoes.dominio.entidades;

import java.io.Serializable;

public class Config implements Serializable {
    public int codigo;
    public String nome;
    public String senha;
    public String celular;

    public Config() {

    }
}

